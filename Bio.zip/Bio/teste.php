<?php
try {
    $pdo = new PDO('mysql:host=127.0.0.1;dbname=biografia_db;charset=utf8', 'root', '');
    echo "✅ Conectado com sucesso ao banco de dados!";
} catch (PDOException $e) {
    echo "❌ Erro ao conectar: " . $e->getMessage();
}
?>
