<?php
header('Content-Type: application/json');


$host = 'localhost';
$dbname = 'portfolio_contatos';
$username = 'root';
$password = '';

$response = [
    'success' => false,
    'message' => ''
];

try {
  
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception("Método não permitido");
    }

    $data = json_decode(file_get_contents('php://input'), true);
 
    if (empty($data['firstName']) || empty($data['email']) || empty($data['message'])) {
        throw new Exception("Por favor, preencha todos os campos obrigatórios.");
    }

    if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        throw new Exception("Por favor, insira um email válido.");
    }

    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


    $stmt = $conn->prepare("INSERT INTO contatos (nome, apelido, email, telefone, mensagem) VALUES (:nome, :apelido, :email, :telefone, :mensagem)");
    
    $stmt->execute([
        ':nome' => $data['firstName'],
        ':apelido' => $data['lastName'] ?? '',
        ':email' => $data['email'],
        ':telefone' => $data['phone'] ?? '',
        ':mensagem' => $data['message']
    ]);

    $response['success'] = true;
    $response['message'] = "Mensagem enviada com sucesso! Entrarei em contacto em breve.";

} catch (PDOException $e) {
    $response['message'] = "Erro no banco de dados: " . $e->getMessage();
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
?>